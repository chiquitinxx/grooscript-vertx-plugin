package grooscript.vertx

class GrooScriptVertxTagLib {

    def static final VERTX_EVENTBUS_BEAN = 'eventBus'

    def reloadPage = {

        if (applicationContext.containsBean(VERTX_EVENTBUS_BEAN)) {

            def eventBus = applicationContext.getBean(VERTX_EVENTBUS_BEAN)

            //out << r.require(module: 'vertx')
            //out << r.script() {
            out << '''
            <script>
                var eb = new vertx.EventBus(\'''' + eventBus.getUrlEventBus() +'''\');

                eb.onopen = function() {

                    console.log('Started.');

                    eb.registerHandler('reloadPage', function(message) {

                        console.log('Got message on reloadPage: ' + JSON.stringify(message));

                    });
                }
            </script>
            '''
        }
    }

    def reloadPage2 = {

        if (applicationContext.containsBean(VERTX_EVENTBUS_BEAN)) {

            def eventBus = applicationContext.getBean(VERTX_EVENTBUS_BEAN)

            out << r.require(module: 'vertx')
            out << r.script() {
                out << '''
                    var eb = new vertx.EventBus(\'''' + eventBus.getUrlEventBus() +'''\');

                    eb.onopen = function() {

                        console.log('Started.');

                        eb.registerHandler('reloadPage', function(message) {

                            console.log('Got message on reloadPage: ' + JSON.stringify(message));

                        });
                    }
                '''
            }
        }
    }

    def reloadPage3 = {

        if (applicationContext.containsBean(VERTX_EVENTBUS_BEAN)) {

            def eventBus = applicationContext.getBean(VERTX_EVENTBUS_BEAN)

            out << r.script() {
                out << '''
                    var eb = new vertx.EventBus(\'''' + eventBus.getUrlEventBus() +'''\');

                    eb.onopen = function() {

                        console.log('Started.');

                        eb.registerHandler('reloadPage', function(message) {

                            console.log('Got message on reloadPage: ' + JSON.stringify(message));

                        });
                    }
                '''
            }
        }
    }

}
