package grooscript.vertx

class MainController {

    def index() { }
}
