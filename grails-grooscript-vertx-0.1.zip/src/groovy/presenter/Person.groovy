package presenter

/**
 * User: jorgefrancoleza
 * Date: 24/02/13
 */
class Person {

    def a
    def b
}
