function Message() {
  var gSobject = inherit(gsBaseClass,'Message');
  gSobject.salute = function(who) {
    console.log('Hello '+who+'!');
  }
  gSobject.Message1 = function(map) { gSpassMapToObject(map,this); return this;};
  if (arguments.length==1) {gSobject.Message1(arguments[0]); }
  
  return gSobject;
};


gSmethodCall(Message(),"salute",gSlist(["Jorge"]));
